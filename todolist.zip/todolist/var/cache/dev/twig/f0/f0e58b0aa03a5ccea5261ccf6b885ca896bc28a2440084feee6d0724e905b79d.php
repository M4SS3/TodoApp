<?php

/* base.html.twig */
class __TwigTemplate_511d9add2ab4e2e77353fb5fdce348638843d263500000c620f57752d8e251b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee61364203e7345100c0a4c2d004953820c8a65e578d44f9c0da26cd038b9ba1 = $this->env->getExtension("native_profiler");
        $__internal_ee61364203e7345100c0a4c2d004953820c8a65e578d44f9c0da26cd038b9ba1->enter($__internal_ee61364203e7345100c0a4c2d004953820c8a65e578d44f9c0da26cd038b9ba1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 16
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
  </head>

  <body>

    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"#\">TodoList</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/\">Home</a></li>
            <li><a href=\"/todo/create\">Add Todo</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class=\"container\">
<div class=\"row\">
    <div class=\"col-md-12\">
       ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 46
            echo "        <div class=\"alert alert-success\">
         ";
            // line 47
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "
         </div>
       ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "       
       ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 52
            echo "        <div class=\"alert alert-danger\">
         ";
            // line 53
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "
         </div>
       ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "       
        ";
        // line 57
        $this->displayBlock('body', $context, $blocks);
        // line 58
        echo "    </div>
</div>
      

    </div><!-- /.container -->
    ";
        // line 63
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "  </body>
</html>
";
        
        $__internal_ee61364203e7345100c0a4c2d004953820c8a65e578d44f9c0da26cd038b9ba1->leave($__internal_ee61364203e7345100c0a4c2d004953820c8a65e578d44f9c0da26cd038b9ba1_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_b8778b0661168b0e51c73d6a0b05b0c179a10ec46acf71103a314d19440b63e8 = $this->env->getExtension("native_profiler");
        $__internal_b8778b0661168b0e51c73d6a0b05b0c179a10ec46acf71103a314d19440b63e8->enter($__internal_b8778b0661168b0e51c73d6a0b05b0c179a10ec46acf71103a314d19440b63e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Todo";
        
        $__internal_b8778b0661168b0e51c73d6a0b05b0c179a10ec46acf71103a314d19440b63e8->leave($__internal_b8778b0661168b0e51c73d6a0b05b0c179a10ec46acf71103a314d19440b63e8_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5de4957093cd8ba2859feecc9328014c724ff6175ac4809bd4a611a9b37c6e5e = $this->env->getExtension("native_profiler");
        $__internal_5de4957093cd8ba2859feecc9328014c724ff6175ac4809bd4a611a9b37c6e5e->enter($__internal_5de4957093cd8ba2859feecc9328014c724ff6175ac4809bd4a611a9b37c6e5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_5de4957093cd8ba2859feecc9328014c724ff6175ac4809bd4a611a9b37c6e5e->leave($__internal_5de4957093cd8ba2859feecc9328014c724ff6175ac4809bd4a611a9b37c6e5e_prof);

    }

    // line 57
    public function block_body($context, array $blocks = array())
    {
        $__internal_00d53fc9ec59a62d5f40cb23ce0de85776706e394ac1d75cff2f5a70960f5552 = $this->env->getExtension("native_profiler");
        $__internal_00d53fc9ec59a62d5f40cb23ce0de85776706e394ac1d75cff2f5a70960f5552->enter($__internal_00d53fc9ec59a62d5f40cb23ce0de85776706e394ac1d75cff2f5a70960f5552_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_00d53fc9ec59a62d5f40cb23ce0de85776706e394ac1d75cff2f5a70960f5552->leave($__internal_00d53fc9ec59a62d5f40cb23ce0de85776706e394ac1d75cff2f5a70960f5552_prof);

    }

    // line 63
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e4ef5812ea97720ad2a72c8e9ce2ce0a7cb79ba683069a249b13b8eb2dd9d9ba = $this->env->getExtension("native_profiler");
        $__internal_e4ef5812ea97720ad2a72c8e9ce2ce0a7cb79ba683069a249b13b8eb2dd9d9ba->enter($__internal_e4ef5812ea97720ad2a72c8e9ce2ce0a7cb79ba683069a249b13b8eb2dd9d9ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_e4ef5812ea97720ad2a72c8e9ce2ce0a7cb79ba683069a249b13b8eb2dd9d9ba->leave($__internal_e4ef5812ea97720ad2a72c8e9ce2ce0a7cb79ba683069a249b13b8eb2dd9d9ba_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 63,  161 => 57,  150 => 16,  138 => 12,  129 => 64,  127 => 63,  120 => 58,  118 => 57,  115 => 56,  106 => 53,  103 => 52,  99 => 51,  96 => 50,  87 => 47,  84 => 46,  80 => 45,  48 => 17,  46 => 16,  39 => 12,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="en">*/
/*   <head>*/
/*     <meta charset="utf-8">*/
/*     <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1">*/
/*     <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->*/
/*     <meta name="description" content="">*/
/*     <meta name="author" content="">*/
/*     <link rel="icon" href="../../favicon.ico">*/
/* */
/*     <title>{% block title %}Symfony Todo{% endblock %}</title>*/
/* */
/*     <!-- Bootstrap core CSS -->*/
/*     <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*     {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*   </head>*/
/* */
/*   <body>*/
/* */
/*     <nav class="navbar navbar-inverse">*/
/*       <div class="container">*/
/*         <div class="navbar-header">*/
/*           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">*/
/*             <span class="sr-only">Toggle navigation</span>*/
/*             <span class="icon-bar"></span>*/
/*             <span class="icon-bar"></span>*/
/*             <span class="icon-bar"></span>*/
/*           </button>*/
/*           <a class="navbar-brand" href="#">TodoList</a>*/
/*         </div>*/
/*         <div id="navbar" class="collapse navbar-collapse">*/
/*           <ul class="nav navbar-nav">*/
/*             <li><a href="/">Home</a></li>*/
/*             <li><a href="/todo/create">Add Todo</a></li>*/
/*           </ul>*/
/*         </div><!--/.nav-collapse -->*/
/*       </div>*/
/*     </nav>*/
/* */
/*     <div class="container">*/
/* <div class="row">*/
/*     <div class="col-md-12">*/
/*        {% for flash_message in app.session.flashbag.get('notice') %}*/
/*         <div class="alert alert-success">*/
/*          {{flash_message}}*/
/*          </div>*/
/*        {% endfor %}*/
/*        */
/*        {% for flash_message in app.session.flashbag.get('error') %}*/
/*         <div class="alert alert-danger">*/
/*          {{flash_message}}*/
/*          </div>*/
/*        {% endfor %}*/
/*        */
/*         {% block body %}{% endblock %}*/
/*     </div>*/
/* </div>*/
/*       */
/* */
/*     </div><!-- /.container -->*/
/*     {% block javascripts %}{% endblock %}*/
/*   </body>*/
/* </html>*/
/* */
