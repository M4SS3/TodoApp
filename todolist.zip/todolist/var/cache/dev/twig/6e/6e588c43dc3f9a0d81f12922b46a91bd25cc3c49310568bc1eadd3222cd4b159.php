<?php

/* todo/edit.html.twig */
class __TwigTemplate_67bbcabdc4c6a90f232bfa15c353ce7a7770e6c1955b3bfdb326d0c272668cd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "todo/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed53092d8db01b543f3e1d9dbd0164566dc0fb1ab8036fde118bdcdd1f166cfd = $this->env->getExtension("native_profiler");
        $__internal_ed53092d8db01b543f3e1d9dbd0164566dc0fb1ab8036fde118bdcdd1f166cfd->enter($__internal_ed53092d8db01b543f3e1d9dbd0164566dc0fb1ab8036fde118bdcdd1f166cfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "todo/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed53092d8db01b543f3e1d9dbd0164566dc0fb1ab8036fde118bdcdd1f166cfd->leave($__internal_ed53092d8db01b543f3e1d9dbd0164566dc0fb1ab8036fde118bdcdd1f166cfd_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0a84af64a4c1dbcdfc08c05fc62e153951fd178759d42feeb00fe11090651883 = $this->env->getExtension("native_profiler");
        $__internal_0a84af64a4c1dbcdfc08c05fc62e153951fd178759d42feeb00fe11090651883->enter($__internal_0a84af64a4c1dbcdfc08c05fc62e153951fd178759d42feeb00fe11090651883_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2 class=\"page-header\">Edit Todo</h2>
";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 8
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_0a84af64a4c1dbcdfc08c05fc62e153951fd178759d42feeb00fe11090651883->leave($__internal_0a84af64a4c1dbcdfc08c05fc62e153951fd178759d42feeb00fe11090651883_prof);

    }

    public function getTemplateName()
    {
        return "todo/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 8,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/* */
/* <h2 class="page-header">Edit Todo</h2>*/
/* {{form_start(form)}}*/
/* {{form_widget(form)}}*/
/* {{form_end(form)}}*/
/* */
/* */
/* {% endblock %}*/
