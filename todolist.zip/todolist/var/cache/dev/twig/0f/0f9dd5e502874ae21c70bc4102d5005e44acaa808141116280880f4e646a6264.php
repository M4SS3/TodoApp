<?php

/* todo/create.html.twig */
class __TwigTemplate_0b214546d4acc9502a88dec92a0d638de112798436ff54bf930c615a81cb2d97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "todo/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd8717e0b2ef400e098ca66defa367ff415c8816dca6b8f14f521b6ae7c72463 = $this->env->getExtension("native_profiler");
        $__internal_dd8717e0b2ef400e098ca66defa367ff415c8816dca6b8f14f521b6ae7c72463->enter($__internal_dd8717e0b2ef400e098ca66defa367ff415c8816dca6b8f14f521b6ae7c72463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "todo/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd8717e0b2ef400e098ca66defa367ff415c8816dca6b8f14f521b6ae7c72463->leave($__internal_dd8717e0b2ef400e098ca66defa367ff415c8816dca6b8f14f521b6ae7c72463_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_fc496c5c3b412c3ffffc088f35f2aa10a87893e78e189e6de25ece4eec0a926a = $this->env->getExtension("native_profiler");
        $__internal_fc496c5c3b412c3ffffc088f35f2aa10a87893e78e189e6de25ece4eec0a926a->enter($__internal_fc496c5c3b412c3ffffc088f35f2aa10a87893e78e189e6de25ece4eec0a926a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2 class=\"page-header\">Add Todo</h2>
";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        // line 8
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


";
        
        $__internal_fc496c5c3b412c3ffffc088f35f2aa10a87893e78e189e6de25ece4eec0a926a->leave($__internal_fc496c5c3b412c3ffffc088f35f2aa10a87893e78e189e6de25ece4eec0a926a_prof);

    }

    public function getTemplateName()
    {
        return "todo/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  52 => 8,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/* */
/* <h2 class="page-header">Add Todo</h2>*/
/* {{form_start(form)}}*/
/* {{form_widget(form)}}*/
/* {{form_end(form)}}*/
/* */
/* */
/* {% endblock %}*/
